'''

https://github.com/yya518/FinBERT/blob/master/FinBERT-demo.ipynb

'''



from transformers import BertTokenizer, BertForSequenceClassification, pipeline

import pandas as pd
# tested in transformers==4.18.0 
import transformers
transformers.__version__

import os,sys
sys.path.append(os.getcwd())

import pysentiment2 as ps


#%%data import using stocktwits-2020-2022-raw data
df=pd.read_csv("data/stocktwits-2020-2022-raw/TSLA_2020_2022/TSLA_20220301_015820.csv").head(100)
df['sentiment']=df['entities'].apply(lambda x: eval(x)['sentiment'])
df=df[['id','body','sentiment']]

#%%data import using tweets-about-the-top-companies-from-2015-to-2020
#note that this dataset does not have sentiment tagging from the author
#The author use Loughran-McDonald financial sentiment analysis library to generate sentiment, see https://sraf.nd.edu/loughranmcdonald-master-dictionary/
#https://pypi.org/project/pysentiment2/
df=pd.read_csv("data/tweets-about-the-top-companies-from-2015-to-2020/Tweet.csv").head(100)
df.rename(columns={'tweet_id':'id'},inplace=True)
df=df[['id','body']]

#initializa class pysentiment2
lm = ps.LM()
results=[]
for body in df['body'].to_list():
    tokens = lm.tokenize(body)
    score = lm.get_score(tokens)
    results.append(score)
df_results= pd.DataFrame(results)
df=pd.concat([df, df_results], axis=1)


#%%Sentiment Analysis
'''

Analyzing financial text sentiment is valuable as it can engage the views and opinions of managers, information intermediaries and investors. FinBERT-Sentiment is a FinBERT model fine-tuned on 10,000 manually annotated sentences from analyst reports of S&P 500 firms.

Input: A financial text.

Output: Positive, Neutral or Negative.


'''
finbert = BertForSequenceClassification.from_pretrained('yiyanghkust/finbert-tone',num_labels=3)
tokenizer = BertTokenizer.from_pretrained('yiyanghkust/finbert-tone')
nlp = pipeline("text-classification", model=finbert, tokenizer=tokenizer)
'''
results = nlp(['growth is strong and we have plenty of liquidity.', 
               'there is a shortage of capital, and we need extra financing.',
              'formulation patents might protect Vasotec to a limited extent.'])
'''
results = nlp(df['body'].to_list())
df_results= pd.DataFrame(results)
df=pd.concat([df, df_results], axis=1)
#%% ESG-Classification

'''
ESG analysis can help investors determine a business' long-term sustainability and identify associated risks. FinBERT-ESG is a FinBERT model fine-tuned on 2,000 manually annotated sentences from firms' ESG reports and annual reports.

Input: A financial text.

Output: Environmental, Social, Governance or None.
'''
finbert = BertForSequenceClassification.from_pretrained('yiyanghkust/finbert-esg',num_labels=4)
tokenizer = BertTokenizer.from_pretrained('yiyanghkust/finbert-esg')
nlp = pipeline("text-classification", model=finbert, tokenizer=tokenizer)
results = nlp(['Managing and working to mitigate the impact our operations have on the environment is a core element of our business.',
               'Rhonda has been volunteering for several years for a variety of charitable community programs.',
               'Cabot\'s annual statements are audited annually by an independent registered public accounting firm.',
               'As of December 31, 2012, the 2011 Term Loan had a principal balance of $492.5 million.'])
df = pd.DataFrame(results)


