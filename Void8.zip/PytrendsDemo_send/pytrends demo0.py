#%% import
import pytrends
from pytrends.request import TrendReq
import pickle
import pandas as pd
import os
import yfinance as yf
import matplotlib.pyplot as plt
os.chdir(os.path.dirname(os.path.abspath(__file__)))

#%% settings and parameters
ticker = 'BCE'
keyword='bell canada'
geo = 'CA'
gprop = ''



'''

#%% fetch stock price and pytrend, save them as pickle
# Get historical data for a specific date range
historical_data = yf.Ticker(ticker).history(start="2024-01-01", end="2024-06-30").reset_index()
historical_data['Date'] = pd.to_datetime(historical_data['Date']).dt.date
#print(historical_data.head())

#pytrend
pytrends = TrendReq(tz=360, retries=5, backoff_factor=0.1)

pytrends.build_payload(kw_list=[keyword], cat=0, timeframe='2024-01-01 2024-06-30', geo=geo, gprop='')
#pytrends.build_payload(kw_list=[keyword], cat=0, timeframe='today 3-m', geo='CA', gprop='')


#get related topics and queries
try:
    related_topics = pytrends.related_topics()
    #related_topics[keyword]['top']
except:
    related_topics=[]
try:
    related_queries = pytrends.related_queries()
    #related_queries[keyword]['top']
except:
    related_queries=[]
#if build from topic first search for topic then build the payload, topic generated from pytrends.related_topics() method, see https://stackoverflow.com/questions/47389000/pytrends-how-to-specify-a-word-as-a-topic-instead-of-a-search-term
#keyword="/m/07zmbvf" #example for  Topic "NASDAQ:AAPL"
#pytrends.build_payload(kw_list=[keyword], cat=0, timeframe='2024-01-01 2024-06-30', geo='', gprop='')


#get interest over time
interest_over_time_df = pytrends.interest_over_time().reset_index()

# Dump data

with open('data/Interest_'+'_'.join((ticker,keyword,geo,gprop))+'.pkl', 'wb') as file: 
    pickle.dump(interest_over_time_df, file) 
with open('data/HistoricalPrice_'+'_'.join((ticker,keyword,geo,gprop))+'.pkl', 'wb') as file: 
    pickle.dump(historical_data, file) 
with open('data/RelatedTopics_'+'_'.join((ticker,keyword,geo,gprop))+'.pkl', 'wb') as file: 
    pickle.dump(related_topics, file) 
with open('data/RelatedQueries_'+'_'.join((ticker,keyword,geo,gprop))+'.pkl', 'wb') as file: 
    pickle.dump(related_queries, file) 
'''




#%% load data
with open('data/Interest_'+'_'.join((ticker,keyword,geo,gprop))+'.pkl', 'rb') as file: 
    interest_over_time_df = pickle.load(file) 
with open('data/HistoricalPrice_'+'_'.join((ticker,keyword,geo,gprop))+'.pkl', 'rb') as file: 
    historical_data = pickle.load(file) 
with open('data/RelatedTopics_'+'_'.join((ticker,keyword,geo,gprop))+'.pkl', 'rb') as file: 
    related_topics = pickle.load(file) 
with open('data/RelatedQueries_'+'_'.join((ticker,keyword,geo,gprop))+'.pkl', 'rb') as file: 
    related_queries = pickle.load(file) 

# plot
if len(interest_over_time_df)==0:
    correlation='N/A'
else:
    interest_over_time_df['Date'] = pd.to_datetime(interest_over_time_df['date']).dt.date  #format date
    interest_over_time_df.rename(columns={keyword: 'trend'}, inplace=True)  #rename column
    #print(interest_over_time_df.head())

    #%% merge pytrend data with the stock data

    df_merge = pd.merge(interest_over_time_df[['Date', 'trend']],
                        historical_data[['Date', 'Close']],
                        on='Date', how='left')

    #ffill and bfill
    df_merge.ffill(inplace=True)
    df_merge.bfill(inplace=True)

    #%% generate correlation
    correlation = df_merge['Close'].corr(df_merge['trend'])
    correlation = f"{correlation:.3f}"

    #%% plots
    # Create the combined plot
    ax = df_merge.plot(x='Date', y='Close')
    df_merge.plot(x='Date', y='trend', ax=ax)

    # Add a title
    plt.title("Stock Close and Trend for " + ticker+", keyword:"+keyword+", corr="+correlation)

    # Show the plot
    #plt.show()
    plt.savefig('plots/'+'_'.join((ticker,keyword,geo,gprop))+'.png')

    plt.close("All")


    
    
print(ticker,keyword,geo,gprop,correlation,sep=',')

