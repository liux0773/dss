


import os,sys
sys.path.append(os.getcwd())
import pandas as pd
from fuzzywuzzy import fuzz
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# 创建数据帧
df_a = pd.read_csv("A.csv")
df_b = pd.read_csv("B.csv")

# 更新 Full Name 列
def update_full_name(full_name):
    parts = full_name.split(', ')
    if len(parts) == 2:
        return f"{parts[1]} {parts[0]}"
    else:
        return full_name

# 应用更新函数到数据集 A
df_b['User Display Name'] = df_b['User Display Name'].apply(update_full_name)



# 使用 CountVectorizer 计算 Jaccard 相似度
vectorizer = CountVectorizer(analyzer='char', ngram_range=(2,2))
X_a = vectorizer.fit_transform(df_a['Full Name'])
X_b = vectorizer.transform(df_b['User Display Name'])

# 计算余弦相似度
cosine_sim = cosine_similarity(X_a, X_b)


# 初始化匹配结果列表
matches = []

# 遍历数据集 B 中的每一行
for i, row_b in df_b.iterrows():
    best_match_idx = cosine_sim[:, i].argmax()
    best_match_name = df_a.loc[best_match_idx, 'Full Name']
    confidence = cosine_sim[best_match_idx, i]
    matches.append((row_b['User Display Name'], best_match_name, confidence))

# 创建匹配结果数据帧
df_matches = pd.DataFrame(matches, columns=['User Display Name', 'Matched Full Name', 'Confidence'])

# 打印匹配结果
print(df_matches)

