#%% import
import pytrends
from pytrends.request import TrendReq
import pickle
import pandas as pd

#%% seetings and parameters
ticker = 'BCE'

#%% pytrend
pytrends = TrendReq(hl='en-US', tz=360, retries=5, backoff_factor=0.1)

keyword='BCE INC'
pytrends.build_payload(kw_list=[keyword], cat=0, timeframe='2024-01-01 2024-06-30', geo='', gprop='news')
interest_over_time_df = pytrends.interest_over_time().reset_index()

#get related topics and queries
related_topics = pytrends.related_topics()
related_topics[keyword]['top']
related_queries = pytrends.related_queries()
related_queries[keyword]['top']

#%%
#if build from topic first search for topic then build the payload, topic generated from pytrends.related_topics() method, see https://stackoverflow.com/questions/47389000/pytrends-how-to-specify-a-word-as-a-topic-instead-of-a-search-term
#keyword="/m/07zmbvf" #example for  Topic "NASDAQ:AAPL"
#pytrends.build_payload(kw_list=[keyword], cat=0, timeframe='2024-01-01 2024-06-30', geo='', gprop='')


#get interest over time
interest_over_time_df = pytrends.interest_over_time().reset_index()
interest_over_time_df['Date'] = pd.to_datetime(interest_over_time_df['date']).dt.date  #format date
interest_over_time_df.rename(columns={keyword: 'trend'}, inplace=True)  #rename column
print(interest_over_time_df.head())

print('end')
#%% fetch stock price

import yfinance as yf
import pandas as pd

# Get historical data for a specific date range
historical_data = yf.Ticker(ticker).history(start="2024-01-01", end="2024-06-30").reset_index()
historical_data['Date'] = pd.to_datetime(historical_data['Date']).dt.date

print(historical_data.head())

#%% merge pytrend data with the stock data

df_merge = pd.merge(historical_data[['Date', 'Close']],
                    interest_over_time_df[['Date', 'trend']],
                    on='Date', how='left')

#%% plots

import matplotlib.pyplot as plt

# Create the combined plot
ax = df_merge.plot(x='Date', y='Close')
df_merge.plot(x='Date', y='trend', ax=ax)

# Add a title
plt.title("Stock Close Price and Trend Over Time for " + ticker)

# Show the plot
plt.show()

#%% generate correlation

correlation = df_merge['Close'].corr(df_merge['trend'])
print(correlation)

# %%
