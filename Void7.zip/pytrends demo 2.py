#%% import

'''

from pytrends.request import TrendReq as UTrendReq #https://stackoverflow.com/questions/50571317/pytrends-the-request-failed-google-returned-a-response-with-code-429
#use https://curlconverter.com/ to get the header
GET_METHOD='get'

import requests


class TrendReq(UTrendReq):
    def _get_data(self, url, method=GET_METHOD, trim_chars=0, **kwargs):
        return super()._get_data(url, method=GET_METHOD, trim_chars=trim_chars, headers=headers, **kwargs)
'''


from pytrends.request import TrendReq

requests_args = {
    'headers': {
        'accept': 'application/json, text/plain, */*',
    'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6,zh-TW;q=0.5,fr;q=0.4',
     'cookie': '__utma=10102256.428023586.1720499352.1720499352.1720541129.2; __utmc=10102256; __utmz=10102256.1720541129.2.2.utmcsr=trends.google.com|utmccn=(referral)|utmcmd=referral|utmcct=/; __utmt=1; __utmb=10102256.3.10.1720541129; SID=g.a000lgitBOMqfpQvO6liQ7KPNjGh2hYkajDLl8mNlaGGOtCq8ujqbl_rZZuoOeR8NZlmRWIyuQACgYKATgSARASFQHGX2MiiCw6sbFgSPKXtujZlMwJTBoVAUF8yKraA7hLGPcQz3n_ySBu4TzQ0076; __Secure-1PSID=g.a000lgitBOMqfpQvO6liQ7KPNjGh2hYkajDLl8mNlaGGOtCq8ujq9uobbr02iEJVUY7jRwqekgACgYKAc0SARASFQHGX2MiJeiJ32k9UYMEqthDS_odpBoVAUF8yKrTHTApQv0JpMzAd2RW_LNA0076; __Secure-3PSID=g.a000lgitBOMqfpQvO6liQ7KPNjGh2hYkajDLl8mNlaGGOtCq8ujqPQpOlVJDziuJrJlPcl1cgAACgYKAR4SARASFQHGX2MiZ9CtzTZRkVGP7-gmuv_I-hoVAUF8yKoo3ylOx8Du4ALeMi10OBE-0076; HSID=ASyMPj48k57zpH98w; SSID=AfqP4LqNb-JNW4iOX; APISID=2Ntkq2YMO7COfS7J/AQFSSPZB8jM3zu-6_; SAPISID=exJvyUAgQt-dG6-N/AddG9SOfyi_igJzaM; __Secure-1PAPISID=exJvyUAgQt-dG6-N/AddG9SOfyi_igJzaM; __Secure-3PAPISID=exJvyUAgQt-dG6-N/AddG9SOfyi_igJzaM; NID=515=FVKc1SJYp9oOLb3Izhg7G6tWf9b_Q045QyeZDRFGgb4rRaQqOGArd36NhDxP0QW8zPmtCSUGCq0iW_Nk7Q_ISQ40c4ybkv29ysZ_C8adhGcc4dp0FyhRH77ZDSdYtoWjh8C6g8JPa_rb1-XyfYsfxmVF0Z8YHnGPmvh3oKPnTjZZxlISefBYtJxq8h7VAbCIYKtEKSadErDxnaf8YhAv5y0-xeRNyMQc86E76Z9DI3L5SvmJejqnfDUUrikcCUMA8RIMUMBnvXD8-kKf06RFPATinV-Xsl66AkF3se6Cpt2_7Yv7PzHIxNlFdq54Em9s54nxZKA9B0Fj7DZxUhhYzl_leyQ3eXbyUv6bTcoWfQFq7OJsXRpsh2_K19OvEKeKIML7MJo5TNpf8S3VReQXPvSywEqEHni_tR464Xc; SEARCH_SAMESITE=CgQIx5sB; AEC=AVYB7cpSEUf2IwOGGEkwGUR7msgRZI94H6o1z_FcjCeAHhNQmjO9oMmIn2o; OTZ=7636589_84_88_104280_84_446940; S=billing-ui-v3=muBjGTDwRIUYa-r9PO0PQ-BGBDdVwrU4:billing-ui-v3-efe=muBjGTDwRIUYa-r9PO0PQ-BGBDdVwrU4; __Secure-1PSIDTS=sidts-CjIB4E2dkT0UL92YpMA9G7shcCq4CWq_jhlqbr7_mWq4yIq0GbSk6Dp2cXpetO5DqAV6hhAA; __Secure-3PSIDTS=sidts-CjIB4E2dkT0UL92YpMA9G7shcCq4CWq_jhlqbr7_mWq4yIq0GbSk6Dp2cXpetO5DqAV6hhAA; SIDCC=AKEyXzXuAhu0jNh6bLahWTp7cehFDZ0qUwEecVXik8w149W70va7CUxjXnFkbRMPucP41aXKhw; __Secure-1PSIDCC=AKEyXzWaNyT2v8zwyTkG9gT-AQCNo6fHQC9hw7LxmjJIUQwhdoHw0lwOoU3ln_Tqej5KMUypWw; __Secure-3PSIDCC=AKEyXzX2u-k_X73DOOSb4whgqH8WBZxpRQOvsDlGg6vWNJ5XH3OROrr14SHEnoRZedJahboWNrI',
    'priority': 'u=1, i',
    'referer': 'https://trends.google.com/trends/explore?date=now%201-d&geo=CA&q=Argentin,asas&hl=zh-CN',
    'sec-ch-ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"',
    'sec-ch-ua-arch': '"x86"',
    'sec-ch-ua-bitness': '"64"',
    'sec-ch-ua-form-factors': '"Desktop"',
    'sec-ch-ua-full-version': '"126.0.6478.127"',
    'sec-ch-ua-full-version-list': '"Not/A)Brand";v="8.0.0.0", "Chromium";v="126.0.6478.127", "Google Chrome";v="126.0.6478.127"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-model': '""',
    'sec-ch-ua-platform': '"Windows"',
    'sec-ch-ua-platform-version': '"10.0.0"',
    'sec-ch-ua-wow64': '?0',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
}
}

# Only need to run this once, the rest of requests will use the same session.
pytrend = TrendReq(requests_args=requests_args)




#%% seetings and parameters
ticker='NYSE Parsons'

#%% pytrend

from pytrends.request import TrendReq

#pytrends = TrendReq(hl='en-US', tz=360,retries=3)
pytrends = TrendReq(retries=3)
keyword=ticker#+' stock'#specify the keyword here
pytrends.build_payload(kw_list=[keyword], cat=0, timeframe='2024-01-01 2024-06-30', geo='', gprop='news')
interest_over_time_df=pytrends.interest_over_time().reset_index()


#get related topics and queries
related_topics=pytrends.related_topics()
related_topics[keyword]['top']
related_queries=pytrends.related_queries()
related_queries[keyword]['top']

#%%
#if build from topic first search for topic then build the payload, topic generated from pytrends.related_topics() method, see https://stackoverflow.com/questions/47389000/pytrends-how-to-specify-a-word-as-a-topic-instead-of-a-search-term
keyword="/m/07zmbvf" #example for  Topic "NASDAQ:AAPL"
pytrends.build_payload(kw_list=[keyword], cat=0, timeframe='2024-01-01 2024-06-30', geo='', gprop='')


#get interest over time
interest_over_time_df=pytrends.interest_over_time().reset_index()
interest_over_time_df['Date']=pd.to_datetime(interest_over_time_df['date']).dt.date #format date
interest_over_time_df.rename(columns={keyword:'trend'},inplace=True)#rename column
print(interest_over_time_df.head())


print('end')
#%% fetch stock price

import yfinance as yf
import pandas as pd


# Get historical data for a specific date range
historical_data = yf.Ticker(ticker).history(start="2024-01-01", end="2024-06-30").reset_index()
historical_data['Date']=pd.to_datetime(historical_data['Date']).dt.date

print(historical_data.head())

#%% merge pytrend data with the stock data

df_merge=pd.merge(historical_data[['Date','Close']],
                  interest_over_time_df[['Date','trend']],
                  on='Date',how='left')

#%% plots

import matplotlib.pyplot as plt

# Create the combined plot
ax = df_merge.plot(x='Date', y='Close')
df_merge.plot(x='Date', y='trend', ax=ax)

# Add a title
plt.title("Stock Close Price and Trend Over Time for "+ticker)

# Show the plot
plt.show()


#%% generate correlation

correlation = df_merge['Close'].corr(df_merge['trend'])
print(correlation)

# %%
