'''

Ref
https://huggingface.co/blog/sentiment-analysis-twitter

GitHub:
    https://github.com/yya518/FinBERT/tree/master for FinBERT-Pretrained, FinBERT-Sentiment, FinBERT-ESG, and FinBERT-FLS

Data from:
    https://www.kaggle.com/competitions/tweet-sentiment-extraction/data?select=train.csv
    
    

'''
import os,sys
import pandas as pd
from IPython.display import display
import requests
sys.path.append(os.getcwd())


df_twitter=pd.read_csv('data/tweet-sentiment-extraction/train.csv')
tweets=df_twitter.head(100)['text'].values


#%% specify model and PI token
model_base = "cardiffnlp/twitter-roberta-base-sentiment-latest"
model_finbert = "ProsusAI/finbert"
model_finbert_tone = "yiyanghkust/finbert-tone"

model_selected=model_finbert
hf_token = "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" ## Huggingface token


API_URL = "https://api-inference.huggingface.co/models/" + model_selected
headers = {"Authorization": "Bearer %s" % (hf_token)}


#function
def analysis(data):
    payload = dict(inputs=data, options=dict(wait_for_model=True))
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.json()


tweets_analysis = []
for tweet in tweets:
    try:
        sentiment_result = analysis(tweet)[0]
        top_sentiment = max(sentiment_result, key=lambda x: x['score']) # Get the sentiment with the higher score
        tweets_analysis.append({'tweet': tweet, 'sentiment': top_sentiment['label']})
 
    except Exception as e:
        print(e)
        

# Load the data in a dataframe
pd.set_option('max_colwidth', None)
pd.set_option('display.width', 3000)
df = pd.DataFrame(tweets_analysis)#this is the aggregated output

'''
# Show a tweet for each sentiment
display(df[df["sentiment"] == 'Positive'].head(1))
display(df[df["sentiment"] == 'Neutral'].head(1))
display(df[df["sentiment"] == 'Negative'].head(1))
'''

#Next, you'll count the number of tweets that were tagged as positive, negative and neutral:
sentiment_counts = df.groupby(['sentiment']).size()
print(sentiment_counts)


#Then, let's create a pie chart to visualize each sentiment in relative terms:
import matplotlib.pyplot as plt
fig = plt.figure(figsize=(6,6), dpi=100)
ax = plt.subplot(111)
sentiment_counts.plot.pie(ax=ax, autopct='%1.1f%%', startangle=270, fontsize=12, label="")



from wordcloud import WordCloud
from wordcloud import STOPWORDS
 
# Wordcloud with positive tweets
positive_tweets = df['tweet'][df["sentiment"] == 'Positive']
stop_words = ["https", "co", "RT"] + list(STOPWORDS)
positive_wordcloud = WordCloud(max_font_size=50, max_words=50, background_color="white", stopwords = stop_words).generate(str(positive_tweets))
plt.figure()
plt.title("Positive Tweets - Wordcloud")
plt.imshow(positive_wordcloud, interpolation="bilinear")
plt.axis("off")
plt.show()
 
# Wordcloud with negative tweets
negative_tweets = df['tweet'][df["sentiment"] == 'Negative']
stop_words = ["https", "co", "RT"] + list(STOPWORDS)
negative_wordcloud = WordCloud(max_font_size=50, max_words=50, background_color="white", stopwords = stop_words).generate(str(negative_tweets))
plt.figure()
plt.title("Negative Tweets - Wordcloud")
plt.imshow(negative_wordcloud, interpolation="bilinear")
plt.axis("off")
plt.show()