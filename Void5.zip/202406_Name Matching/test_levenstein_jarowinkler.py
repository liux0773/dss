

import os,sys
sys.path.append(os.getcwd())
import pandas as pd
from fuzzywuzzy import fuzz
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from jellyfish import jaro_winkler_similarity

# 创建数据帧
df_a = pd.read_csv("A.csv")
df_b = pd.read_csv("B.csv")

# 更新 Full Name 列
def update_full_name(full_name):
    parts = full_name.split(', ')
    if len(parts) == 2:
        return f"{parts[1]} {parts[0]}"
    else:
        return full_name

# 应用更新函数到数据集 A
df_b['User Display Name'] = df_b['User Display Name'].apply(update_full_name)


# 使用 fuzzywuzzy 库计算匹配度
def calculate_levenshtein_similarity(row_a, row_b):
    return fuzz.token_set_ratio(row_a['Full Name'], row_b['User Display Name'])

# 计算 Jaro-Winkler 相似度
def calculate_jaro_winkler_similarity(row_a, row_b):
    return jaro_winkler_similarity(row_a['Full Name'], row_b['User Display Name'])



# 初始化匹配结果列表
matches = []

# 遍历数据集 B 中的每一行
for _, row_b in df_b.iterrows():
    best_match = None
    best_confidence = 0

    # 遍历数据集 A 中的每一行
    for _, row_a in df_a.iterrows():
        confidence = calculate_levenshtein_similarity(row_a, row_b)
        if confidence > best_confidence:
            best_match = row_a['Full Name']
            best_confidence = confidence

    # 添加匹配结果到列表
    matches.append((row_b['User Display Name'], row_b['Index'],row_a['Employee ID'],best_match, best_confidence))

# 创建匹配结果数据帧
df_matches = pd.DataFrame(matches, columns=['User Display Name','Index','Employee ID', 'Matched Full Name', 'Confidence'])

# 打印匹配结果
print(df_matches)

